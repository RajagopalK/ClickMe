﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;

public partial class productinsert : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader dr;
    static string fn;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=USER-PC;Initial Catalog=onlinebike;Integrated Security=True");
        generate();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
        //insert
        string img = "~/images/" + fn.ToString();
        con.Open();
        cmd = new SqlCommand("insert into pro values("+pid.Text+",'"+pname.Text+"','"+ptype.Text+"','"+pmil.Text+"',"+pprice.Text+",'"+img.ToString()+"')", con);
        cmd.ExecuteNonQuery();
        msg.Text = "Product Inserted";
        cmd.Dispose();
        con.Close();

        pname.Text = "";
        ptype.Text = "";
        pmil.Text = "";
        pprice.Text = "";
        generate();
            }
    protected void generate()
    {
        con.Open();
        cmd = new SqlCommand("select top 1 pid from pro order by pid desc", con);
        cmd.ExecuteNonQuery();
        dr= cmd.ExecuteReader();
        if (dr.Read())
        {
            string s1 = dr[0].ToString();
            int i1 = int.Parse(s1);
            i1 = i1 + 1;
            pid.Text = i1.ToString();
        }
        dr.Close();
        cmd.Dispose();
        con.Close();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        //View Images
        fn = Path.GetFileName(pimage.PostedFile.FileName);
        if (pimage.HasFile)
        {
            pimage.SaveAs(Server.MapPath("~/images/") + pimage.FileName);
            Image1.Visible = true;
            Image1.ImageUrl = "~/images/" + pimage.FileName;
        }
        

    }
    
}
