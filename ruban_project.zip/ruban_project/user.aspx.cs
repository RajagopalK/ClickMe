﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class user : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=USER-PC;Initial Catalog=onlinebike;Integrated Security=True");
    }
    
    protected void Button1_Click(object sender, EventArgs e)
    {
        //Login
        con.Open();
        cmd = new SqlCommand("select uid, pwd from userreg where uid='"+uname.Text+"' and pwd='"+pwd.Text+"' ", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            Session["username"] = uname.Text;
            Response.Redirect("viewproduct.aspx");
        }
        else
            msg.Text = "Invalid User";
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("userreg.aspx");
    }
}
