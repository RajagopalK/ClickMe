﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Data.SqlClient;

public partial class viewproduct : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {
        TextBox1.Text = Session["username"].ToString(); 

        con = new SqlConnection("Data Source=USER-PC;Initial Catalog=onlinebike;Integrated Security=True");
        if (!IsPostBack)
        {
            con.Open();
            cmd = new SqlCommand("select distinct ptype from pro", con);
            cmd.ExecuteNonQuery();
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ptype.Items.Add(dr[0].ToString());
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        //con.Open();
        //cmd = new SqlCommand("select * from pro", con);
        //cmd.ExecuteNonQuery();
        //dr=cmd.ExecuteReader();
        //DataList1.DataSource = dr;
        //DataList1.DataBind();
        //con.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        cmd = new SqlCommand("select * from pro where ptype='"+ptype.SelectedItem.ToString()+"'", con);
        cmd.ExecuteNonQuery();
        dr = cmd.ExecuteReader();
        DataList2.DataSource = dr;
        DataList2.DataBind();       
        con.Close();
        
    }
    //protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    //{
        
    //    //Response.Redirect("payment.aspx");    
    //}
    protected void DataList2_ItemCommand(object source, DataListCommandEventArgs e)
    {
        Session["uid"] = TextBox1.Text;
        Response.Redirect("payment.aspx?pid=" + e.CommandArgument.ToString());
        
    }
    protected void DataList2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
        
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
}
