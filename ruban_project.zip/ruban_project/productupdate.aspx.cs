﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;

public partial class productupdate : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader dr;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=USER-PC;Initial Catalog=onlinebike;Integrated Security=True");
        if (!IsPostBack)
        {
            con.Open();
            cmd = new SqlCommand("select pid from pro", con);
            cmd.ExecuteNonQuery();
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                pid.Items.Add(dr[0].ToString());
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
        }

    }
    protected void pid_SelectedIndexChanged(object sender, EventArgs e)
    {
        pname.Enabled = true;
        pmil.Enabled = true;
        pprice.Enabled = true;
        ptype.Enabled = true;
        

        con.Open();
        cmd = new SqlCommand("select pname,ptype,milage,price from pro where pid='"+pid.SelectedItem.ToString()+"'", con);
        cmd.ExecuteNonQuery();
        dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            pname.Text = dr[0].ToString();
            ptype.Text = dr[1].ToString();
            pmil.Text = dr[2].ToString();
            pprice.Text = dr[3].ToString();
            
        }
        dr.Close();
        cmd.Dispose();
        con.Close();

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //update
        con.Open();
        cmd = new SqlCommand("update pro set pname='"+pname.Text+"',ptype='"+ptype.Text+"',milage='"+pmil.Text+"',price='"+pprice.Text+"' where pid='"+pid.SelectedItem.ToString()+"' ", con);
        cmd.ExecuteNonQuery();
        msg.Text = "Updated";
        cmd.Dispose();
        con.Close();
        view();
        clear();
        ena();        
    }
   
    
    protected void view()
    {
        //view all
        con.Open();
        cmd = new SqlCommand("select * from pro", con);
        cmd.ExecuteNonQuery();
        dr = cmd.ExecuteReader();
        GridView1.DataSource = dr;
        GridView1.DataBind();
        dr.Close();
        cmd.Dispose();
        con.Close();
    }
    protected void clear()
    {
        pname.Text = "";
        ptype.Text = "";
        pmil.Text = "";
        pprice.Text = "";
       
        
    }
    protected void ena()
    {
        pname.Enabled = false;
        ptype.Enabled = false;
        pmil.Enabled = false;
        pprice.Enabled = false;
        
    }
}

