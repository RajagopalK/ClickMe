﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class userreg : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=USER-PC;Initial Catalog=onlinebike;Integrated Security=True");
        generate();
    }
    protected void generate()
    {
        con.Open();
        cmd = new SqlCommand("select count(uid) from userreg", con);
        cmd.ExecuteNonQuery();
        dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            string s1 = dr[0].ToString();
            int i1 = int.Parse(s1);
            i1 = i1 + 1;
            uid.Text = i1.ToString();
        }
        dr.Close();
        cmd.Dispose();
        con.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //insert
        con.Open();
        cmd = new SqlCommand("insert into userreg values(" + uid.Text + ",'" + name.Text + "','" + mailid.Text + "','" + mobile.Text + "','" + address.Text + "','" +pwd.Text + "')", con);
        cmd.ExecuteNonQuery();
        msg.Text = "Registration Successfully";
        cmd.Dispose();
        con.Close();
        name.Text = "";
        mailid.Text = "";
        mobile.Text="";
        address.Text="";
        pwd.Text="";
        rpwd.Text = "";
        Response.Redirect("user.aspx");
    }
}
