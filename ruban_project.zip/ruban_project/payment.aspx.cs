﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Data.SqlClient;

public partial class payment : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=USER-PC;Initial Catalog=onlinebike;Integrated Security=True");
        string idd = Request.QueryString["pid"].ToString();
        TextBox1.Text = Session["uid"].ToString();
        TextBox2.Text = idd.ToString();
        pdet();
        udet();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       //payment
        msg.Text = "Paid Successfully";
        
    }
    protected void pdet()
    {
        con.Open();
        cmd=new SqlCommand("select pname,ptype,price from pro where pid="+TextBox2.Text+"",con);
        cmd.ExecuteNonQuery();
        dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            pname.Text = dr[0].ToString();
            ptype.Text = dr[1].ToString();
            price.Text = dr[2].ToString();
        }
        dr.Close();
        cmd.Dispose();
        con.Close();
    }
    protected void udet()
    {
        con.Open();
        cmd = new SqlCommand("select name,mailid from userreg where uid=" + TextBox1.Text + "", con);
        cmd.ExecuteNonQuery();
        dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            name.Text = dr[0].ToString();
            email.Text = dr[1].ToString();
        }
        dr.Close();
        cmd.Dispose();
        con.Close();
    }
    
}
