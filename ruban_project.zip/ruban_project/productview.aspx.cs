﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class productview : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=USER-PC;Initial Catalog=onlinebike;Integrated Security=True");
        if (!IsPostBack)
        {
            con.Open();
            cmd = new SqlCommand("select pid from pro", con);
            cmd.ExecuteNonQuery();
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                DropDownList1.Items.Add(dr[0].ToString());
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //view
        con.Open();
        cmd=new SqlCommand("select * from pro where pid='"+DropDownList1.SelectedItem.ToString()+"'",con);
        cmd.ExecuteNonQuery();
        dr = cmd.ExecuteReader();
        GridView1.DataSource = dr;
        GridView1.DataBind();
        dr.Close();
        cmd.Dispose();
        con.Close();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        //view all
        con.Open();
        cmd = new SqlCommand("select * from pro", con);
        cmd.ExecuteNonQuery();
        dr = cmd.ExecuteReader();
        GridView1.DataSource = dr;
        GridView1.DataBind();
        dr.Close();
        cmd.Dispose();
        con.Close();
    }
}
